import xbmcaddon
import xbmcgui
import logger
import tools
import re
import xbmcplugin
import urlparse
import json
import sys 
import urllib
import datetime

args = urlparse.parse_qs(sys.argv[2][1:])

#recuperar el argumento action
action = args.get('action', None)
domain = "http://vivenetvision.com/Neg_Categorias_VOD.aspx?val=1" #aqui la url de netvision, editar el val (nro contrato)
domain_thumbnail = "http://vivenetvision.com/"
addon_handle = int(sys.argv[1])

if action is None:
	#Aqui solo entra la primera vez para que el usuario pueda escoger categorias de las pelis
	html = tools.getUrl(domain)
	logger.debug(html)

	#########################################################Cuadro de dialogo
	#__addon__ = xbmcaddon.Addon()
	#__addonname__ = __addon__.getAddonInfo('name')
	#line1 = "BIENVENIDOS"
	#line2 = "A LA SECCION DE PELICULAS Y SERIES DE NETVISION."
	#line3 = "Enjoy :)"
	#xbmcgui.Dialog().ok(__addonname__, line1, line2, line3)
	#########################################################

	pattern = '<figure>(.*?)</figure>'
	matches = tools.findall(pattern, html, re.DOTALL)

	for match in matches:
		pattern = 'ng-href="#/category/(.*?)"'
		category = tools.findall(pattern, match, re.DOTALL)[0]
		
		pattern = 'rev="(.*?)"'
		fecha = tools.findall(pattern, match, re.DOTALL)[0]
		
		pattern = 'longdesc="(.*?)"'
		sinopsis = tools.findall(pattern, match, re.DOTALL)[0]
		
		pattern = 'height="(.*?)"'
		duracion = tools.findall(pattern, match, re.DOTALL)[0]
	
		pattern = 'alt="(.*?)"'
		titulo = tools.findall(pattern, match, re.DOTALL)[0]
		
		pattern = 'src="(.*?)"'
		thumbnail = tools.findall(pattern, match, re.DOTALL)[0]
		
		thumbnail = thumbnail.replace("./", "/")
		thumbnail = domain_thumbnail + thumbnail
		
		pattern = 'id="(.*?)"'
		url = "http://vivenetvision.com/VOD/" + tools.findall(pattern, match, re.DOTALL)[0]
	
		xbmcplugin.setContent(addon_handle, 'episodes') # movies audio or episodes
		#tools.addItemMenu(label = label, thumbnail = thumbnail, url = url, IsPlayable = 'true', isFolder = False)
		li = xbmcgui.ListItem(label = titulo)
		li.setIconImage(thumbnail)
		li.setArt({'thumb': thumbnail, 'poster': thumbnail, 'fanart': thumbnail})
		
		info = {
		'genre': 'Comedia', 'year': 1979, 'title': titulo, 'duration' : duracion, 'tagline' : category,
		'plotoutline' : sinopsis, 'aired' : fecha
		}
		li.setInfo('video', info)
		
		video_info  =  {'codec': 'h264', 'aspect': 1.78, 'width': 1280, 'height': 720}
		li.addStreamInfo('video', video_info)
		li.addStreamInfo('audio', {'codec': 'dts', 'language': 'en', 'channels': 2})
		li.addStreamInfo('subtitle', {'language': 'en'})
		
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
		
	xbmcplugin.endOfDirectory(addon_handle)
