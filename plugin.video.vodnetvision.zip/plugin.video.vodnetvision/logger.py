import xbmc

def debug(message):
	xbmc.log("NETVISION: " + message)